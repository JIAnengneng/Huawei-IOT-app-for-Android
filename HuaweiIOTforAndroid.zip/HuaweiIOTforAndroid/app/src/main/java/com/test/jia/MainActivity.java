package com.test.jia;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(MainActivity.this, "首次连接请等待",Toast.LENGTH_SHORT ).show();
        Button btupdate=(Button)findViewById(R.id.button_Con);
        Button btnexitiot=(Button)findViewById(R.id.button_exitiot);
        Switch swled=(Switch)findViewById(R.id.switch_led);
        Switch swwindows=(Switch)findViewById(R.id.switch_windows);
        final ImageView imageView_line=(ImageView)findViewById(R.id.imageView_line);
        final ImageView imageView_led=(ImageView)findViewById(R.id.imageView_led);
        final ImageView imageView_windows=(ImageView)findViewById(R.id.imageView_windows);
        final TextView textview_temp=(TextView) findViewById(R.id.textView_temp);
        final TextView textview_humi=(TextView) findViewById(R.id.textView_humi);
        final TextView textView_light=(TextView) findViewById(R.id.textView_light);
        final TextView textView_status=(TextView) findViewById(R.id.textView_status);
        final TextView textView_led=(TextView) findViewById(R.id.textView_led);

        final Thread t = new Thread() {
            @Override
            public void run() {
                try {
                    HuaweiIOT hwiot=new HuaweiIOT();
                    System.out.println("获取状态");
                    String str="";
                    str=hwiot.getAtt("","status");
                    if(str.equals("OFFLINE")) {
                        str = "设备离线";
                        imageView_line.setImageDrawable(getResources().getDrawable(R.drawable.outline));
                    }
                    else if(str.equals("ONLINE"))
                    {
                        str="设备在线";
                        imageView_line.setImageDrawable(getResources().getDrawable(R.drawable.online));
                    }
                    textView_status.setText(str);
                    System.out.println("获取温度");
                    str=hwiot.getAtt("temp","shadow");
                    textview_temp.setText(str+"℃");
                    System.out.println("获取成功，温度："+str);
                    str=hwiot.getAtt("humi","shadow");
                    textview_humi.setText(str+"%");
                    System.out.println("获取成功，湿度："+str);
                    str=hwiot.getAtt("light","shadow");
                    textView_light.setText(str+"lx");
                    System.out.println("获取成功，光照强度："+str);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("获取失败："+e.toString());
                }
            }
        };
        t.start();
        Toast.makeText(MainActivity.this, "属性获取中",Toast.LENGTH_LONG ).show();

        btupdate.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                Thread t = new Thread() {
                    @Override
                    public void run() {
                        try {
                            HuaweiIOT hwiot=new HuaweiIOT();
                            System.out.println("获取状态");
                            String str="";
                            str=hwiot.getAtt("","status");
                            if(str.equals("OFFLINE")) {
                                str = "设备离线";
                                imageView_line.setImageDrawable(getResources().getDrawable(R.drawable.outline));
                            }
                            else if(str.equals("ONLINE"))
                            {
                                str="设备在线";
                                imageView_line.setImageDrawable(getResources().getDrawable(R.drawable.online));
                            }
                            textView_status.setText(str);
                            System.out.println("获取温度");
                            str=hwiot.getAtt("temp","shadow");
                            textview_temp.setText(str+"℃");
                            System.out.println("获取成功，温度："+str);
                            str=hwiot.getAtt("humi","shadow");
                            textview_humi.setText(str+"%");
                            System.out.println("获取成功，湿度："+str);
                            str=hwiot.getAtt("light","shadow");
                            textView_light.setText(str+"lx");
                            System.out.println("获取成功，光照强度："+str);
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                            System.out.println("获取失败："+e.toString());
                        }
                    }
                };
                t.start();
                Toast.makeText(MainActivity.this, "属性获取中",Toast.LENGTH_SHORT ).show();
            }
        });
        swled.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    Thread t = new Thread() {
                        @Override
                        public void run() {
                            try {
                                HuaweiIOT hwiot=new HuaweiIOT();
                                System.out.println("命令下发");
                                imageView_led.setImageDrawable(getResources().getDrawable(R.drawable.ledon));
                                hwiot.setCom("led","1");
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                System.out.println("下发失败："+e.toString());
                            }
                        }
                    };
                    t.start();
                    Toast.makeText(MainActivity.this, "命令下发中",Toast.LENGTH_SHORT ).show();
                }else {
                    Thread t = new Thread() {
                        @Override
                        public void run() {
                            try {
                                HuaweiIOT hwiot=new HuaweiIOT();
                                System.out.println("命令下发");
                                imageView_led.setImageDrawable(getResources().getDrawable(R.drawable.ledoff));
                                hwiot.setCom("led","0");
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                System.out.println("下发失败："+e.toString());
                            }
                        }
                    };
                    t.start();
                    Toast.makeText(MainActivity.this, "命令下发中",Toast.LENGTH_SHORT ).show();
                }
            }
        });
        btnexitiot.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                showNormalDialog("确定退出程序吗？",2);
            }
        });
        swwindows.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    Thread t = new Thread() {
                        @Override
                        public void run() {
                            try {
                                HuaweiIOT hwiot=new HuaweiIOT();
                                System.out.println("命令下发");
                                imageView_windows.setImageDrawable(getResources().getDrawable(R.drawable.onwindows));
                                hwiot.setCom("windows","1");

                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                System.out.println("下发失败："+e.toString());
                            }
                        }
                    };
                    t.start();
                    Toast.makeText(MainActivity.this, "命令下发中",Toast.LENGTH_SHORT ).show();
                }else {
                    Thread t = new Thread() {
                        @Override
                        public void run() {
                            try {
                                HuaweiIOT hwiot=new HuaweiIOT();
                                System.out.println("命令下发");
                                imageView_windows.setImageDrawable(getResources().getDrawable(R.drawable.offwindows));
                                hwiot.setCom("windows","0");
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                System.out.println("下发失败："+e.toString());
                            }
                        }
                    };
                    t.start();
                    Toast.makeText(MainActivity.this, "命令下发中",Toast.LENGTH_SHORT ).show();
                }
            }
        });
    }
    private void showNormalDialog(String strtip,int num){
        final int a=num;
        //创建dialog构造器
        AlertDialog.Builder normalDialog = new AlertDialog.Builder(this);
        //设置title
        normalDialog.setTitle("温馨提示：");
        //设置icon
        normalDialog.setIcon(R.drawable.ic_launcher_round);
        //设置内容
        normalDialog.setMessage(strtip);
        //设置按钮
        normalDialog.setPositiveButton(getString(R.string.sure)
                , new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        System.out.println("确定");
                        if(a>1) finish();
                    }
                });
        if(a==2)
            normalDialog.setNegativeButton(getString(R.string.cancel)
                    , new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            System.out.println("取消");
                        }
                    });
        //创建并显示
        normalDialog.create().show();
    }
}








